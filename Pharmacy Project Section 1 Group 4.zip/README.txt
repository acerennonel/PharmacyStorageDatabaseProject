#How to run the project

Step 1: Open SQL Server Management Studio and run the SQL query named "Pharmacy Query.sql". Run the queries one
by one. (Do not run the queries together that has 5 row gap to each other.)

Step 2: Open the project folder in file explorer and right click the "CMPE232.slnx" file. Select "Open
with" and open the file with Visual Studio.

Step 3: In Visual Studio, run the project. The webpage of the project must open in your browser.

#Libraries Used

Entity Framework 6.5.1
Microsoft.AspNetCore.App.Internal.Assets 10.0.1
Microsoft.AspNetCore.Components.QuickGrid.EntityFrameworkAdapter 10.0.1
Microsoft.AspNetCore.Diagnostics.EntityFrameworkCore 10.0.1
Microsoft.EntityFrameworkCore.SqlServer 10.0.1
Microsoft.EntityFrameworkCore.Tools 10.0.1
Microsoft.VisualStudio.Web.CodeGeneration.Design 10.0.1
